package com.example.a10_rickandmorty.data.Model

import com.google.gson.annotations.SerializedName

data class rnmData(

    @SerializedName("name")
    var name: String,

    @SerializedName("species")
    var species: String,

    @SerializedName("image")
    var imageUrl:String
)
