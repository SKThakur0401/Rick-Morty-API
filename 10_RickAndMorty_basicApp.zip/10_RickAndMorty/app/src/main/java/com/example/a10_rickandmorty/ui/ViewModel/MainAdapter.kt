package com.example.a10_rickandmorty.ui.ViewModel

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.a10_rickandmorty.data.Model.rnmData
import com.example.a10_rickandmorty.databinding.SingleRnmCharacterBinding

class MainAdapter(private val rnmDataList:ArrayList<rnmData>):

    RecyclerView.Adapter<MainAdapter.MainViewHolder>(){

    inner class MainViewHolder(private val binding: SingleRnmCharacterBinding):
        RecyclerView.ViewHolder(binding.root){
        fun bind(rnmDataItem: rnmData){
            binding.apply {
                tvName.text =rnmDataItem.name
                tvSpecies.text =rnmDataItem.species

                Glide.with(imgCharacter.context).load(rnmDataItem.imageUrl).diskCacheStrategy(
                    DiskCacheStrategy.AUTOMATIC
                ).into(imgCharacter)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val binding =
            SingleRnmCharacterBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return MainViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return rnmDataList.size
    }

    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {

        holder.bind(rnmDataList[position])
    }

    fun addCharactersAndData(rnmDataListPassed: ArrayList<rnmData>)
    {
        this.rnmDataList.apply {
            clear()
            addAll(rnmDataListPassed)
        }
    }
}

