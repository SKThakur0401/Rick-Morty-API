package com.example.a10_rickandmorty.utils

enum class Status {
    loading,
    error,
    success
}